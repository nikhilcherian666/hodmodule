CREATE USER 'testuser'@'%' IDENTIFIED BY 'testpassword';
CREATE DATABASE testdatabase;
GRANT ALL PRIVILEGES ON *.* TO 'testuser'@'%' ;
