<?php
session_start();
include("includes/header.php");
include("includes/connection1.php");
include("includes/report_errors.php");
include("includes/sidenav.php");
include("includes/classess/c_hod.php");
$obj=new hod;
?>

<div id="page-wrapper">   
	<div class="row"><div class="col-lg-12" >
         <h1 class="page-header"> Faculty Details</h1>
            </div>
            
<table border="1" align="center" 
           style="background-color: #FFFFFF; width: 955px;" cellpadding="5">
            
            <tr style="font-family: 'Times New Roman', Times, serif; 
                font-size: 18px; font-weight: bold; color: #FFFFFF; 
                background-color: #000000">                                          
<div class="row">
                <div class="col-lg-12">
			
	<div class=".col-sm-6 .col-md-5 .col-md-offset-2 .col-lg-6 .col-lg-offset-0">
<table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
  <tr>
    <th>Faculty ID</th>
	 <th>Faculty Name</th>
    <th>Department</th>
	<th>E-Mail ID</th>
	<th>Contact Number</th>
	<th>Photo</th>
	<th>Edit</th>
	<th>Delete</th>
	</tr>

<?php 
	include("includes/footer.php");
?>
