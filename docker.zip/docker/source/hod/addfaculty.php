<?php
session_start();
include("includes/header.php");
include("includes/connection1.php");
include("includes/report_errors.php");
include("includes/sidenav.php");
include("includes/classess/c_hod.php");
$obj=new hod;
$r=$obj->getinfo();
foreach($r as $row)
{
    $_SESSION['fname']=$row["name"];  
    $_SESSION['deptname']=$row["deptname"];
    
}

if (isset($_POST['submit'])) 
{  
	$fid=strtoupper($_POST['fid']);
	$name=strtoupper($_POST['name']);
	$deptname=$_SESSION['deptname'];
	$phoneno=$_POST['phoneno'];
	$email=$_POST['email'];
    $obj->insertdata("$fid","$name","$deptname","$phoneno","$email");
}
    
    //faculty id from session
//READING FACULTY NAME AND DEPARTMENT
    // $resul=mysqli_query($conn,"select name,deptname from faculty_details where fid='DUMMY1'");
    // while($dat=mysqli_fetch_array($resul))
    // {
    //     $fname=$dat["name"];
    //     $fdeptname=$dat["deptname"];
    //     $_SESSION["deptname"]=$fdeptname;

    // }
//reading class id from staff adviser   
//    $resul=mysql_query("select classid from class_details where deptname in(select deptname from department where hod='$hodid')");
  //  while($dat=mysql_fetch_array($resul))
    //{
      // $classid=$dat["classid"];
    //}
    //$_SESSION["classid"]=$classid;
?>
  <script src="jquery.js"></script>
<script>


	function validate()
	{
		var s1 = document.getElementById('deptname').value;
		if(s1=="--select--"){
			alert("Please select department");
			return false;
		}
		return true;
	} 

</script>
<div id="page-wrapper">   
	<div class="row">
		<div class="col-lg-12" >
			<h1 class="page-header">Faculty Registration</h1>
		</div>


		<form id="addemp" name="form1"  method = "POST" enctype = "multipart/form-data" onsubmit="return validate();">
			<table  id="outer1" align="center" style="padding-top:40px">
				<tr>
					<td>Faculty_ID(KTU_ID): <span class="required">*</span></td>
					<td><input required="required" autocomplete="off" class="form-control"   id="Text1" type="text" name="fid" style="text-transform:uppercase; width: 400px" /></td>					
				</tr>
				<tr>
					<td>Name: <span class="required">*</span></td>
					<td><input required="required" autocomplete="off" class="form-control" id="name" type="text" name="name" style="text-transform:uppercase; width: 400px" pattern="[a-zA-Z\s\.]+"/></td>					
				</tr>
				<!--<tr>
					<td>Department: <span class="required">*</span></td>
					<td><select name="deptname" id="deptname" class="form-control" >
					<option value="--select--">--select--</option>
					<?php
 						// $sql="select * from department";
						// $r=mysql_query($sql,$con);
						// while($result=mysql_fetch_array($r)){
						// 	echo '<option value="'.$result['deptname'].'">'.$result['deptname'].'</option>';
						// }
					?>
					</select>
					</td>
				</tr>-->
				<tr>
					<td>Phone No.: <span class="required">*</span></td>
					<td><input  required="required" class="form-control" autocomplete="off" maxlength="10" minlength="10" id="Text1" type="number" name="phoneno" style="width: 400px" /></td>					
				</tr>
				<tr>
					<td>Email: <span class="required">*</span></td>
					<td><input  required="required" class="form-control" autocomplete="off" maxlength="80" minlength="5"  id="Text1" type="email" name="email" style="width:400px;" /></td>					
				</tr>
				<tr>
					<td>Photo:</td>
					<td><input type="file" name="file" id="image"  ></td>
					<td id="thumb-output"></td>					
				</tr>
				
				<tr align="center">
					<td><input style="width:200px" id="submit" class="btn btn-primary" type="submit" value="Register" name="submit"/></td>										
				</tr>
			</table>		
		</form>
	</div>
</div>
<script>
	$(document).ready(function(){
    $('#image').on('change', function(){ //on file input change
        if (window.File && window.FileReader && window.FileList && window.Blob) //check File API supported browser
        {
            $('#thumb-output').html(''); //clear html of output element
            var data = $(this)[0].files; //this file data
            
            $.each(data, function(index, file){ //loop though each file
                if(/(\.|\/)(gif|jpe?g|png)$/i.test(file.type)){ //check supported file type
                    var fRead = new FileReader(); //new filereader
                    fRead.onload = (function(file){ //trigger function on successful read
                    	return function(e) {
                    		var img = $('<img/>').addClass('thumb').attr('src', e.target.result)
                    		.width('100px')
           				.height('100px'); //create image element 
                        $('#thumb-output').append(img); //append image to output element
                    };
                })(file);
                    fRead.readAsDataURL(file); //URL representing the file's data.
                }
            });
            
        }else{
            alert("Your browser doesn't support File API!"); //if File API is absent
        }
    });
});
</script>

<?php 

include("includes/footer.php");
?>