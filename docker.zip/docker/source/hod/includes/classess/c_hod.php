<?php

include("./includes/report_errors.php");

/**
 * hod
 */
class hod
{
//    public $user_details;
//       public   $conn;
//         public $fname;
    
   public function getinfo()
    {  
         include("./includes/connection1.php");
         $sql="select * from faculty_details where fid='DUMMY1'";
         $result=$conn->query( $sql );
        while($row = $result->fetch_assoc()){
            $this->user_details[]=$row;
        }
        return $this->user_details;
    }
//=========================================================================================================
    public function random_password( $length = 8 ) 
    {
        $chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789@";
        $password = substr( str_shuffle( $chars ), 0, $length );
        return $password;
    }
//=========================================================================================================
    public function insertdata($fid,$name,$deptname,$phoneno,$email)
    {
        include("./includes/connection1.php");
     $this->fid=$fid;
     $this->name=$name;
     $this->deptname=$deptname;
     $this->phoneno=$phoneno;
     $this->email=$email;

    $ch="select * from faculty_details where email='$email'";
    
    $res=$conn->query($ch);
    if ($res->num_rows > 0)
    {
        echo " 
        <script type=\"text/javascript\"> 
        alert(\"User Already Exists with the given mail id.\");
        location.replace(\"addfaculty.php\");
    </script> " ;
    
    }
    $check="select * from faculty_details where fid like '$fid'";
	$result=$conn->query($check);
	if ($result->num_rows > 0) 
	{
		
      echo "
		<script type=\"text/javascript\"> alert(\"User Already Exists\");
		location.replace(\"addfaculty.php\");
	</script> ";
    }
    else	
    {

	$image0 = null;
			// if(!isset( $_FILES['file']))
	if(!$_FILES['file']['tmp_name']=="")
		$image0 = addslashes(file_get_contents($_FILES['file']['tmp_name']));


	$sql ="insert into faculty_details(fid,name,deptname,phoneno,email,photo)value('$fid','$name','$deptname','$phoneno','$email',
	'$image0')";
	

	if($conn->query($sql)== TRUE) 
	{ 
		$pass=$this->random_password(8);
		$conn->query("insert into login values('$email','$pass','faculty')") or die(mysql_error());
		$conn->query("insert into faculty_designation values('$fid','faculty')") or die(mysql_error());
		

           $subjectmail="RITSOFT | Login Details";
           $contentmail='
			Your Login Credentials for RITSOFT Account
			Username: '.$email.'
			Password: '.$pass.'
			------------------------
 			Thanking You';
 			
 			mail($email,$subjectmail,$contentmail);



		}
        echo "<script type=\"text/javascript\"> alert(\"Staff Added Successfully\");
		location.replace(\"addfaculty.php\");
	</script>";

    }
    

    }
 //=========================================================================================================   
}
?>